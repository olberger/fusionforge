# LaTeX2HTML 2002-2-1 (1.71)
# Associate images original text with physical files.


$key = q/>;MSF=1.6;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="16" HEIGHT="31" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img4.png"
 ALT="$&gt;$">|; 

$key = q/<;MSF=1.6;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="16" HEIGHT="31" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img3.png"
 ALT="$&lt;$">|; 

$key = q/nomath_inline}textquestiondownnomath_inline};MSF=1.6;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="8" HEIGHT="20" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img1.png"
 ALT="\textquestiondown">|; 

$key = q/nomath_inline}textexclamdownnomath_inline};MSF=1.6;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="6" HEIGHT="20" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img2.png"
 ALT="\textexclamdown">|; 

1;

