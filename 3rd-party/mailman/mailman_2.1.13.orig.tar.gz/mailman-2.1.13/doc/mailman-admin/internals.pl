# LaTeX2HTML 2002-2-1 (1.71)
# Associate internals original text with physical files.


$key = q/front/;
$ref_files{$key} = "$dir".q|node1.html|; 
$noresave{$key} = "$nosave";

$key = q/contents/;
$ref_files{$key} = "$dir".q|node2.html|; 
$noresave{$key} = "$nosave";

$key = q/about/;
$ref_files{$key} = "$dir".q|node36.html|; 
$noresave{$key} = "$nosave";

1;

